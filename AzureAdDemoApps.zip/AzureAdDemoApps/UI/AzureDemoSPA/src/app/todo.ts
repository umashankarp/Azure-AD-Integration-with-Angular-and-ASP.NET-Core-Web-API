export interface Todo {
  id: number;
  description: string;
  status: boolean;
}